Figure 11: User's behavior of face privacy leakage

根据excel里的数据画堆积图(需要对数据处理一下，处理的方法见图2）
画出来的图的是图2这种样子的
图2里最后的圈1——圈6是对应位置的颜色
颜色以及对颜色的注解的格式参考图1
圈1：No bystander
圈2：Bystander
圈3：No subject
圈4：Subject
圈5：No face
圈6：Face

另外查一下Twitter上 “认证账户”和“普通账户”的英文表达，把中文换成对应的英文